# Aurinne — PWA setup files

This folder contains everything needed to make the Aurinne app installable as a
Progressive Web App (PWA) on phones, using the chosen logo (bordeaux "A" in a
circle, on cream background).

## What's inside

- `manifest.json` — the PWA manifest (name, colours, icons)
- `sw.js` — a basic service worker for offline support
- `index-head-snippet.html` — tags to copy into your `index.html` `<head>`
- `icons/` — all icon sizes generated from the logo:
  - `icon-192.png`, `icon-256.png`, `icon-384.png`, `icon-512.png` — standard icons
  - `icon-maskable-192.png`, `icon-maskable-512.png` — Android adaptive icons (safe padding)
  - `apple-touch-icon.png` — iOS home screen icon (180x180)
  - `favicon-16.png`, `favicon-32.png` — browser tab favicons
- `icon-source.svg`, `icon-maskable-source.svg` — editable SVG sources, in case
  you want to tweak the icon later

## How to use this

1. Deploy your Aurinne app (the React code) to a hosting service such as
   **Vercel** or **Netlify**.
2. Copy the `icons/` folder, `manifest.json`, and `sw.js` into the **public**
   folder of your project (so they end up at the site root: `/icons/...`,
   `/manifest.json`, `/sw.js`).
3. Open `index-head-snippet.html` and copy its contents into the `<head>` of
   your `index.html`. This:
   - Links the manifest and icons
   - Sets the theme colour to match the app (`#F7F1E8`)
   - Loads the Playfair Display and Quicksand fonts used throughout the app
   - Registers the service worker for offline support

4. Deploy. On iPhone, visiting the site in Safari and choosing
   **"Add to Home Screen"** will install Aurinne with its icon, name, and
   cream/bordeaux theme colour, opening full-screen like a native app.

## Notes

- The journal's "Save entry" feature uses the app's storage — once the app is
  hosted as a real PWA (not inside the Claude.ai preview), this will persist
  reliably on each person's device.
- The "Reflect with AI" feature calls the Anthropic API directly from the
  browser. For a production PWA, this call should go through your own small
  backend (so your API key isn't exposed in the browser) — happy to help with
  that step when you're ready.
